﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestCore.Helper
{
    public enum RoleType
    {
        Customer=1,
        Vendor,
        Admin
    }
}
