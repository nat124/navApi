﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestCore.Helper
{
    public enum NotificationType
    {
        typ = 1,
        PurchaseOrder,
        Shipping,
        Points,
        WishlistStock,
        PistisEvent,
        DealOffer,
        chat
    }
}
