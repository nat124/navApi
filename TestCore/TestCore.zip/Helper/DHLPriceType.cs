﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestCore
{
    public enum DHLPriceType
    {
        ExpressDomestic=1,
        SameDaySprintline =2,
        EconomySelectDomestic=3,
    }
    public enum FedexDeliveryType    {        PRIORITY_OVERNIGHT = 1,        STANDARD_OVERNIGHT = 2,        FEDEX_EXPRESS_SAVER = 3,    }
}
